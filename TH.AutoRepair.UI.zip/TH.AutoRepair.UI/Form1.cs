using TH.AutoRepair.BL;

namespace TH.AutoRepair.UI
{
    public partial class Form1 : Form
    {
        // field (private class variable)
        private List<Customer> customers = new List<Customer>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.FirstName = txtFirstName.Text.Trim();
            customer.LastName = txtLastName.Text.Trim();
            customer.PhoneNumber = txtPhoneNumber.Text.Trim();
            customers.Add(customer);


            lstCustomers.DataSource = null;
            lstCustomers.DataSource = customers;
        
        }

        private void lstCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            Customer? selectedCustomer = lstCustomers.SelectedItem as Customer;
            if (selectedCustomer != null)
            {
                txtFirstName.Text = selectedCustomer.FirstName;
                txtLastName.Text = selectedCustomer.LastName;
                txtPhoneNumber.Text = selectedCustomer.PhoneNumber;
            }
        }
    }
}